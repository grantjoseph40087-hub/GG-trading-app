# GG Trading App

A mobile-friendly demo trading dashboard for learning and testing trading ideas.

## Files
- `index.html` — app structure
- `style.css` — design
- `app.js` — demo trading logic

## Important
This version is **demo/educational only**. It does not connect to a broker or place real trades.
